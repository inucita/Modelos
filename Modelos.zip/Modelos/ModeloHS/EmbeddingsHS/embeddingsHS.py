import pandas as pd
import nltk
import torch
from torch.nn.utils.rnn import pad_sequence
from transformers import BertTokenizer, BertModel
import h5py
from sklearn.model_selection import KFold
from sklearn.metrics import f1_score, precision_score, recall_score, accuracy_score
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Bidirectional, GRU, Dropout, Dense, Flatten
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l1, l2
from tensorflow.keras.callbacks import EarlyStopping
import numpy as np
import tensorflow as tf
import os

# Descarga recursos necesarios de NLTK
nltk.download('wordnet')
nltk.download('omw-1.4')

# Inicializa tokenizer y modelo BERT
tokenizer = BertTokenizer.from_pretrained('bert-base-multilingual-uncased')
model = BertModel.from_pretrained('bert-base-multilingual-uncased')

print("Modelo BERT cargado")

# Función para obtener los embeddings de un texto (forma: batch_size, 768)
def get_bert_embeddings(text_list):
    """
    Procesa una lista de textos, tokeniza y genera embeddings con dimensiones (batch_size, 768).
    """
    # Tokenización y padding
    inputs = tokenizer(text_list, return_tensors='pt', truncation=True, padding=True, max_length=512)

    # Pasar por el modelo BERT
    with torch.no_grad():
        outputs = model(**inputs)

    # Obtener embeddings de la última capa y aplicar mean pooling
    embeddings = outputs.last_hidden_state.mean(dim=1)  # (batch_size, 768)

    return embeddings

# Función para procesar un dataset y generar embeddings
def process_and_embed(dataset, language_column):
    """
    Genera embeddings para todos los textos en el dataset con padding dinámico.
    """
    text_list = [text for text in dataset[language_column].tolist() if isinstance(text, str) and text.strip()]
    batch_size = 32

    all_embeddings = []
    for i in range(0, len(text_list), batch_size):
        batch_texts = text_list[i:i+batch_size]
        embeddings = get_bert_embeddings(batch_texts)  # (batch_size, 768)
        all_embeddings.append(embeddings)

    # Concatenar todos los batches
    full_embeddings = torch.cat(all_embeddings, dim=0)  # (n_texts, 768)
    return full_embeddings

# Función para guardar embeddings en formato HDF5
def save_embeddings_to_hdf5(english_embeddings, spanish_embeddings, file_path_english, file_path_spanish):
    """
    Guarda los embeddings de inglés y español en archivos HDF5 separados.
    """
    with h5py.File(file_path_english, 'w') as f_english, h5py.File(file_path_spanish, 'w') as f_spanish:
        f_english.create_dataset('embeddings', data=english_embeddings.cpu().numpy())
        f_spanish.create_dataset('embeddings', data=spanish_embeddings.cpu().numpy())
    print(f"Embeddings de inglés guardados en {file_path_english}")
    print(f"Embeddings de español guardados en {file_path_spanish}")

# Definir rutas relativas para los archivos
base_folder = os.path.abspath(os.path.join(".."))
preprocessing_folder = os.path.join(base_folder, "Preprocesamiento")
embeddings_folder = os.path.join(base_folder, "EmbeddingsHS")

# Archivos de entrada y salida
dataset_esp_path = os.path.join(preprocessing_folder, 'dataset_preprocessed_esp_updated.csv')
dataset_eng_path = os.path.join(preprocessing_folder, 'dataset_preprocessed_eng_updated.csv')
spanish_embeddings_path = os.path.join(embeddings_folder, 'spanish_embeddings.h5')
english_embeddings_path = os.path.join(embeddings_folder, 'english_embeddings.h5')

# ========== VERIFICACIÓN DE DIRECTORIOS Y ARCHIVOS ==========
print("\n" + "="*80)
print("VERIFICACIÓN DE ESTRUCTURA DE DIRECTORIOS Y ARCHIVOS")
print("="*80)

print("\nDIRECTORIO ACTUAL DE TRABAJO:")
print(f"Ruta absoluta: {os.path.abspath('.')}")
print(f"Contenido: {os.listdir('.')}")

print("\nESTRUCTURA DE CARPETAS REQUERIDAS:")
print(f"1. Carpeta base: {os.path.abspath(base_folder)}")
print(f"   - Existe: {'Sí' if os.path.exists(base_folder) else 'No'}")
print(f"   - Contenido: {os.listdir(base_folder) if os.path.exists(base_folder) else 'No existe'}")

print(f"\n2. Carpeta preprocesamiento: {os.path.abspath(preprocessing_folder)}")
print(f"   - Existe: {'Sí' if os.path.exists(preprocessing_folder) else 'No'}")
print(f"   - Contenido: {os.listdir(preprocessing_folder) if os.path.exists(preprocessing_folder) else 'No existe'}")

print(f"\n3. Carpeta embeddings: {os.path.abspath(embeddings_folder)}")
print(f"   - Existe: {'Sí' if os.path.exists(embeddings_folder) else 'No'}")
print(f"   - Contenido: {os.listdir(embeddings_folder) if os.path.exists(embeddings_folder) else 'No existe'}")

print("\nARCHIVOS DE ENTRADA REQUERIDOS:")
print(f"1. Dataset español: {os.path.abspath(dataset_esp_path)}")
print(f"   - Existe: {'Sí' if os.path.exists(dataset_esp_path) else 'No'}")
print(f"   - Tamaño: {os.path.getsize(dataset_esp_path) if os.path.exists(dataset_esp_path) else 0} bytes")

print(f"\n2. Dataset inglés: {os.path.abspath(dataset_eng_path)}")
print(f"   - Existe: {'Sí' if os.path.exists(dataset_eng_path) else 'No'}")
print(f"   - Tamaño: {os.path.getsize(dataset_eng_path) if os.path.exists(dataset_eng_path) else 0} bytes")

print("\nARCHIVOS DE SALIDA ESPERADOS:")
print(f"1. Embeddings español: {os.path.abspath(spanish_embeddings_path)}")
print(f"2. Embeddings inglés: {os.path.abspath(english_embeddings_path)}")
print("="*80 + "\n")

# Cargar datasets preprocesados
print("Cargando datasets...")
try:
    dataset_esp = pd.read_csv(dataset_esp_path, encoding='utf-8')
    print(f"Dataset español cargado correctamente. Filas: {len(dataset_esp)}")
except Exception as e:
    print(f"No se pudo cargar el dataset español: {str(e)}")
    dataset_esp = None

try:
    dataset_eng = pd.read_csv(dataset_eng_path, encoding='utf-8')
    print(f"Dataset inglés cargado correctamente. Filas: {len(dataset_eng)}")
except Exception as e:
    print(f"No se pudo cargar el dataset inglés: {str(e)}")
    dataset_eng = None

if dataset_eng is not None:
    print("\nValores nulos antes de la eliminación:", dataset_eng['processed_text'].isnull().sum())
    dataset_eng = dataset_eng.dropna(subset=['processed_text'])
    print("Valores nulos después de la eliminación:", dataset_eng['processed_text'].isnull().sum())
    dataset_eng.to_csv(dataset_eng_path, index=False, encoding='utf-8')
    print(f"Dataset inglés limpio guardado en: {os.path.abspath(dataset_eng_path)}")

if dataset_esp is not None:
    print("\nTipo de datos en la columna 'processed_text':", dataset_esp['processed_text'].dtype)
    print("\nTipos de datos en el dataset español:")
    print(dataset_esp.dtypes)
    print("\nEjemplos de textos procesados en español:")
    print(dataset_esp['processed_text'].head())
    print("\nValores únicos en el dataset español (texto procesado):")
    print(dataset_esp['processed_text'].unique())

if dataset_eng is not None:
    print("\nTipos de datos en el dataset inglés:")
    print(dataset_eng.dtypes)
    print("\nEjemplos de textos procesados en inglés:")
    print(dataset_eng['processed_text'].head())
    print("\nValores únicos en el dataset inglés (texto procesado):")
    print(dataset_eng['processed_text'].unique())

print("\n" + "="*50)
print("VERIFICACIÓN DE COLUMNAS")
print("="*50)
if dataset_esp is not None:
    print("Columnas en el dataset español:", dataset_esp.columns.tolist())
else:
    print("No hay dataset español para verificar columnas")

if dataset_eng is not None:
    print("\nColumnas en el dataset inglés:", dataset_eng.columns.tolist())
else:
    print("\nNo hay dataset inglés para verificar columnas")
print("="*50 + "\n")

# Generar embeddings y guardar
if dataset_esp is not None and dataset_eng is not None:
    print("Generando embeddings...")
    spanish_embeddings = process_and_embed(dataset_esp, 'processed_text')
    english_embeddings = process_and_embed(dataset_eng, 'processed_text')

    print("\nGuardando embeddings...")
    save_embeddings_to_hdf5(english_embeddings, spanish_embeddings, english_embeddings_path, spanish_embeddings_path)
    print("\nProceso completado.")
else:
    print("\nNo se pueden generar embeddings porque faltan datasets:")
    if dataset_esp is None:
        print("- Falta el dataset español")
    if dataset_eng is None:
        print("- Falta el dataset inglés")
