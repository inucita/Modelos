import pandas as pd
import re
import os
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer, SnowballStemmer
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import nltk
nltk.download('wordnet') 
nltk.download('omw-1.4')  

# Descargar recursos de NLTK si es necesario
nltk.download('punkt')
nltk.download('stopwords')

# Obtener la carpeta donde está el script
current_dir = os.path.dirname(os.path.abspath(__file__))

# Construir las rutas relativas
csv_path = os.path.join(current_dir, 'labeled_corpus_6K.csv')
tsv_path = os.path.join(current_dir, 'datasetHASOC2019.tsv')

# Leer los archivos
dataset = pd.read_csv(csv_path, encoding='utf-8')
dataset2 = pd.read_csv(tsv_path, sep='\t', encoding='utf-8')

# Verifica las primeras filas de ambos datasets
print("Dataset 1 (CSV):")
print(dataset.head())  

print("\nDataset 2 (TSV):")
print(dataset2.head())  

# Diccionario para almacenar estadísticas
stats = {
    'hashtags': 0,
    'mentions': 0,
    'urls': 0,
    'emojis': 0,
    'non_alpha_chars': 0,
    'stopwords_removed': 0,
    'rt_video_removed': 0
}

# Función de preprocesamiento
def clean_and_preprocess_updated(text, language):
    if not isinstance(text, str):
        return text
    
    # Contar elementos antes de eliminarlos
    stats['hashtags'] += text.count('#')
    stats['mentions'] += text.count('@')
    stats['urls'] += len(re.findall(r'http\S+|www\S+|https\S+', text))
    stats['emojis'] += len(re.findall(r'[^\x00-\x7F]+', text))
    
    # Eliminar completamente los hashtags (como #algo)
    text = re.sub(r'#\S+', '', text)  # Elimina el # seguido de cualquier conjunto de caracteres sin espacios
    
    # Eliminar etiquetas específicas de Twitter como RT y VIDEO
    rt_video_count = len(re.findall(r'\bRT\b|\bVIDEO\b', text))
    stats['rt_video_removed'] += rt_video_count
    text = re.sub(r'\bRT\b|\bVIDEO\b', '', text)
    
    # Reemplazar menciones de usuarios con "@user"
    text = re.sub(r'@\S+', '@user', text)
    
    # Eliminar URLs
    text = re.sub(r'http\S+|www\S+|https\S+', '', text)
    
    # Eliminar emojis (caracteres no ASCII)
    text = re.sub(r'[^\x00-\x7F]+', '', text)
    
    # Convertir a minúsculas
    text = text.lower()
    
    # Contar y eliminar caracteres no alfabéticos (se mantienen solo letras y espacios)
    non_alpha_chars = len(re.findall(r'[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]', text))
    stats['non_alpha_chars'] += non_alpha_chars
    text = re.sub(r'[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]', '', text)
    
    # Eliminar stopwords dependiendo del idioma
    if language == 'spanish':
        stop_words = set(stopwords.words('spanish'))
    elif language == 'english':
        stop_words = set(stopwords.words('english'))
    else:
        stop_words = set()
    
    # Contar y eliminar stopwords
    words = text.split()
    stopwords_count = len([word for word in words if word in stop_words])
    stats['stopwords_removed'] += stopwords_count
    text = ' '.join([word for word in words if word not in stop_words])
    
    # Lematización básica, no se consideró para este preprocesamiento
    lemmatizer = WordNetLemmatizer() if language == 'english' else None  # Usar un lematizador adecuado según idioma
    if lemmatizer:
        text = ' '.join([lemmatizer.lemmatize(word) for word in text.split()])

    return text

# Aplicar el preprocesamiento al dataset en español
dataset['processed_text'] = dataset['texto'].apply(lambda x: clean_and_preprocess_updated(x, 'spanish'))

# Aplicar el preprocesamiento al dataset en inglés
dataset2['processed_text'] = dataset2['text'].apply(lambda x: clean_and_preprocess_updated(x, 'english'))

# Contar valores NaN en el dataset en español
nan_count_esp = dataset['texto'].isna().sum()
print(f"Número de valores NaN en el dataset en español: {nan_count_esp}")
# Contar valores NaN en el dataset en inglés
nan_count_eng = dataset2['text'].isna().sum()
print(f"Número de valores NaN en el dataset en inglés: {nan_count_eng}")
# Eliminar filas donde el texto es NaN
dataset = dataset.dropna(subset=['texto'])  # Para el dataset en español
dataset2 = dataset2.dropna(subset=['text'])  # Para el dataset en inglés
# Imprimir la cantidad de valores nulos antes de la eliminación
print("Valores nulos antes de la eliminación:", dataset2['processed_text'].isnull().sum())
# Eliminar filas con valores nulos en la columna 'processed_text'
dataset2 = dataset2.dropna(subset=['processed_text'])
# Imprimir la cantidad de valores nulos después de la eliminación
print("Valores nulos después de la eliminación:", dataset2['processed_text'].isnull().sum())
# Ajustar para mostrar más caracteres
pd.set_option('display.max_colwidth', None)  # Esto muestra los textos completos en las columnas
# Ver las primeras 3 filas de las columnas relevantes del dataset en español
print("Dataset HaterNet (actualizado)\n")
print(dataset[['texto', 'processed_text']].head(3))
# Ver las primeras 3 filas de las columnas relevantes del dataset en inglés
print("Dataset HASOC2019 (actualizado)\n")
print(dataset2[['text', 'processed_text']].head(3))
print(dataset2.isnull().sum())  # Contar nulos después de cargar los datos

# Mostrar estadísticas de limpieza
print("\nEstadísticas de limpieza:")
print(f"Hashtags eliminados: {stats['hashtags']}")
print(f"Menciones reemplazadas: {stats['mentions']}")
print(f"URLs eliminadas: {stats['urls']}")
print(f"Emojis eliminados: {stats['emojis']}")
print(f"Etiquetas RT/VIDEO eliminadas: {stats['rt_video_removed']}")
print(f"Caracteres no alfabéticos eliminados: {stats['non_alpha_chars']}")
print(f"Stopwords eliminadas: {stats['stopwords_removed']}")

# Guardar los resultados en nuevos archivos CSV dentro de la misma carpeta del script
output_csv_esp = os.path.join(current_dir, 'dataset_preprocessed_esp_updated.csv')
output_csv_eng = os.path.join(current_dir, 'dataset_preprocessed_eng_updated.csv')

dataset.to_csv(output_csv_esp, index=False)
dataset2.to_csv(output_csv_eng, index=False)

print(f"Archivos preprocesados guardados en:\n - {output_csv_esp}\n - {output_csv_eng}")