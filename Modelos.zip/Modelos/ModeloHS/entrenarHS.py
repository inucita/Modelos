import os
import h5py
import torch
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, Bidirectional, Dropout, Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras import regularizers
from sklearn.model_selection import train_test_split, StratifiedKFold
import numpy as np
import matplotlib.pyplot as plt
import itertools
from tensorflow.keras import backend as K
import gc
import math

# Configuración de carpetas
os.makedirs("results", exist_ok=True)
os.makedirs("results/models", exist_ok=True)
os.makedirs("results/plots", exist_ok=True)
os.makedirs("resultados", exist_ok=True)


# VERIFICACIÓN DE DATOS (COMPLETA)

print("="*60)
print("VERIFICACIÓN DE ARCHIVOS Y DATOS")
print("="*60)

# Cargar embeddings
embeddings_path = "C:/Users/brend/Desktop/modelos/ModeloHS/EmbeddingsHS/english_embeddings.h5"
english_embeddings = torch.tensor(h5py.File(embeddings_path, 'r')['embeddings'][:])
print("\nVERIFICACIÓN DE EMBEDDINGS:")
print(f"Ruta: {embeddings_path}")
print(f"Tipo: {type(english_embeddings)}")
print(f"Forma original: {english_embeddings.shape}")

# Cargar labels
csv_path = "C:/Users/brend/Desktop/modelos/ModeloHS/Preprocesamiento/dataset_preprocessed_eng_updated.csv"
df = pd.read_csv(csv_path)
print("\nVERIFICACIÓN DE CSV:")
print(f"Ruta: {csv_path}")
print(f"Total filas: {len(df)}")
print(f"Primeras 5 filas:\n{df.head()}")
print("\nDISTRIBUCIÓN DE CLASES:")
print(df["task_1"].value_counts())

# Procesamiento
english_embeddings_np = english_embeddings.cpu().numpy()
labels = df["task_1"].replace({'NOT': 0, 'HOF': 1}).values

# Verificar dimensiones
if len(english_embeddings_np.shape) == 2:
    english_embeddings_np = np.expand_dims(english_embeddings_np, axis=1)
    print(f"\nSe expandieron los embeddings a: {english_embeddings_np.shape}")

# Asegurar misma cantidad de muestras
min_samples = min(len(english_embeddings_np), len(labels))
english_embeddings_np = english_embeddings_np[:min_samples]
labels_np = labels[:min_samples]
print("\nVERIFICACIÓN FINAL:")
print(f"Muestras totales: {len(english_embeddings_np)}")
print(f"Forma embeddings: {english_embeddings_np.shape}")
print(f"Forma labels: {labels_np.shape}")
print(f"Distribución final:\n{pd.Series(labels_np).value_counts()}")


# DIVISIÓN DE DATOS (80% train+val / 20% test)

# Configuración de datos (AHORA CON 100% DE LOS DATOS)
X_train_val = english_embeddings_np  # Todos los embeddings
y_train_val = labels_np            # Todas las etiquetas
print("\nDISTRIBUCIÓN COMPLETA PARA K-FOLD:")
print(f"Muestras totales: {len(X_train_val)}")
print(f"Distribución de clases:\n{pd.Series(y_train_val).value_counts()}")

#CONFIG DE PREUBA
learning_rates = [0.001]
dropouts = [0.3]
regularizations = ['l2']
early_stoppings = [False]
units_list = [128]
batch_size = 32
epochs =600
# CONFIGURACIÓN DE EXPERIMENTOS (32 COMBINACIONES)

#learning_rates = [0.001, 0.0005]
#dropouts = [0.2, 0.5]
#regularizations = ['l1', 'l2']
#early_stoppings = [True, False]
#units_list = [64, 128]
#batch_size = 32
#epochs = 30

param_combinations = list(itertools.product(
    learning_rates, dropouts, regularizations, early_stoppings, units_list
))
print(f"\nTOTAL DE EXPERIMENTOS: {len(param_combinations)}")


# DEFINICIÓN DEL MODELO (ACTUALIZADO)

def build_model(input_shape, lr, dropout, reg, units):
    if reg == 'l1':
        kernel_reg = regularizers.l1(0.0001)
    else:
        kernel_reg = regularizers.l2(0.0001)

    inputs = Input(shape=input_shape)
    x = Bidirectional(LSTM(units, return_sequences=True, kernel_regularizer=kernel_reg))(inputs)
    x = Dropout(dropout)(x)
    x = Bidirectional(LSTM(units//2, kernel_regularizer=kernel_reg))(x)
    x = Dropout(dropout)(x)
    outputs = Dense(1, activation='sigmoid', kernel_regularizer=kernel_reg)(x)

    model = Model(inputs, outputs)
    model.compile(
        optimizer=Adam(learning_rate=lr),
        loss='binary_crossentropy',
        metrics=['accuracy',
                 tf.keras.metrics.Precision(name='precision'),
                 tf.keras.metrics.Recall(name='recall')]
    )
    return model


# ENTRENAMIENTO CON K-FOLD (5 FOLDS)
kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
df_results = pd.DataFrame(columns=[
    'experiment', 'fold', 'learning_rate', 'dropout', 'regularization',
    'early_stopping', 'units',
    'train_accuracy', 'val_accuracy', 'train_loss', 'val_loss',
    'train_precision', 'val_precision', 'train_recall', 'val_recall',
    'train_f1', 'val_f1'
])

df_epochs = pd.DataFrame(columns=[
    'experiment', 'fold', 'epoch', 'learning_rate', 'dropout', 'regularization',
    'early_stopping', 'units',
    'train_accuracy', 'val_accuracy', 'train_loss', 'val_loss'
])

for exp_idx, (lr, dropout, reg, use_early_stop, units) in enumerate(param_combinations):
    print(f"\n{'='*80}")
    print(f"EXPERIMENTO {exp_idx+1}/{len(param_combinations)}")
    print(f"LR: {lr} | Dropout: {dropout} | Reg: {reg} | EarlyStop: {use_early_stop} | Units: {units}")
    print(f"{'='*80}")

    for fold, (train_idx, val_idx) in enumerate(kf.split(X_train_val, y_train_val)):
        print(f"\nFold {fold+1}/5")
        X_train, X_val = X_train_val[train_idx], X_train_val[val_idx]
        y_train, y_val = y_train_val[train_idx], y_train_val[val_idx]

        # Verificar distribución en el fold
        print(f"Distribución Train: {pd.Series(y_train).value_counts().to_dict()}")
        print(f"Distribución Val: {pd.Series(y_val).value_counts().to_dict()}")

        model = build_model(
            (X_train.shape[1], X_train.shape[2]),
            lr, dropout, reg, units
        )

        callbacks = []
        if use_early_stop:
            callbacks.append(EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True))

        history = model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            class_weight={0: 1.63, 1: 2.59},
            verbose=1
        )

        # Evaluación final del fold
        train_results = model.evaluate(X_train, y_train, verbose=0)
        val_results = model.evaluate(X_val, y_val, verbose=0)

        fold_data = {
            'experiment': exp_idx + 1,
            'fold': fold + 1,
            'learning_rate': lr,
            'dropout': dropout,
            'regularization': reg,
            'early_stopping': use_early_stop,
            'units': units,
            'train_accuracy': train_results[1],
            'val_accuracy': val_results[1],
            'train_loss': train_results[0],  # Loss es el primer elemento
            'val_loss': val_results[0],
            'train_precision': train_results[2] if len(train_results) > 2 else np.nan,
            'val_precision': val_results[2] if len(val_results) > 2 else np.nan,
            'train_recall': train_results[3] if len(train_results) > 3 else np.nan,
            'val_recall': val_results[3] if len(val_results) > 3 else np.nan,
            'train_f1': 2 * (train_results[2] * train_results[3]) / (train_results[2] + train_results[3] + 1e-7) if len(train_results) > 3 and (train_results[2] + train_results[3]) > 0 else np.nan,
            'val_f1': 2 * (val_results[2] * val_results[3]) / (val_results[2] + val_results[3] + 1e-7) if len(val_results) > 3 and (val_results[2] + val_results[3]) > 0 else np.nan
        }
        df_results = pd.concat([df_results, pd.DataFrame([fold_data])], ignore_index=True)

        num_epochs = len(history.history['accuracy'])
        epochs_list = []
        for epoch in range(num_epochs):
            epoch_data = {
                'experiment': exp_idx + 1,
                'fold': fold + 1,
                'epoch': epoch + 1,
                'learning_rate': lr,
                'dropout': dropout,
                'regularization': reg,
                'early_stopping': use_early_stop,
                'units': units,
                'train_accuracy': history.history['accuracy'][epoch],
                'val_accuracy': history.history['val_accuracy'][epoch] if 'val_accuracy' in history.history else np.nan,
                'train_loss': history.history['loss'][epoch],
                'val_loss': history.history['val_loss'][epoch] if 'val_loss' in history.history else np.nan
            }
            epochs_list.append(epoch_data)
        df_epochs = pd.concat([df_epochs, pd.DataFrame(epochs_list)], ignore_index=True)


        print(f"\nResultados Fold {fold+1} (Última Época):")
        print(f"Train - Acc: {history.history['accuracy'][-1]:.4f} | Loss: {history.history['loss'][-1]:.4f}")
        if 'val_accuracy' in history.history:
            print(f"Val   - Acc: {history.history['val_accuracy'][-1]:.4f} | Loss: {history.history['val_loss'][-1]:.4f}")
        else:
            print("Val - No disponible (Early Stopping activado)")

        # Gráficos (opcional, mismo código que antes)
        plt.figure(figsize=(12, 6))
        plt.plot(history.history['accuracy'], label='Train Accuracy', color='blue', linestyle='-')
        if 'val_accuracy' in history.history:
            plt.plot(history.history['val_accuracy'], label='Val Accuracy', color='red', linestyle='-')
        plt.plot(history.history['loss'], label='Train Loss', color='blue', linestyle='--')
        if 'val_loss' in history.history:
            plt.plot(history.history['val_loss'], label='Val Loss', color='red', linestyle='--')
        plt.xlabel('Épocas')
        plt.ylabel('Métrica')
        plt.title(f'Fold {fold+1} - Accuracy y Loss')
        plt.legend()
        plt.savefig(f"results/plots/exp_{exp_idx+1}_fold_{fold+1}.png")
        plt.close()

        # Guardar modelo
        model.save(f"results/models/exp_{exp_idx+1}_fold_{fold+1}.h5")

        # Limpieza
        K.clear_session()
        gc.collect()

    # Calcular promedios del experimento (usando los datos ya guardados en df_results)
    exp_data = df_results[df_results['experiment'] == (exp_idx + 1)]
    avg_metrics = {
        'experiment': exp_idx + 1,
        'learning_rate': lr,
        'dropout': dropout,
        'regularization': reg,
        'early_stopping': use_early_stop,
        'units': units,
        'avg_train_accuracy': exp_data['train_accuracy'].mean(),
        'avg_val_accuracy': exp_data['val_accuracy'].mean(),
        'avg_train_loss': exp_data['train_loss'].mean(),
        'avg_val_loss': exp_data['val_loss'].mean(),
        'avg_train_f1': exp_data['train_f1'].mean(),
        'avg_val_f1': exp_data['val_f1'].mean()
    }

    # Guardar promedios en un nuevo DataFrame
    df_avg = pd.DataFrame([avg_metrics])
    df_avg.to_excel("resultados/promedios_experimentos.xlsx", index=False)

    print(f"\nResumen Experimento {exp_idx+1}:")
    print(f"Val Accuracy promedio: {avg_metrics['avg_val_accuracy']:.4f}")
    print(f"Val Loss promedio: {avg_metrics['avg_val_loss']:.4f}")
    print(f"Val F1 promedio: {avg_metrics['avg_val_f1']:.4f}")
    df_results.to_excel("resultados/resultados_completos.xlsx", index=False)

   
# Guardar el DataFrame con los resultados por época en un nuevo archivo Excel
df_epochs.to_excel("resultados/resultados_por_epoca.xlsx", index=False)
print("\nResultados por época guardados en 'resultados/resultados_por_epoca.xlsx'")

# Guardar modelo final
#final_model.save("results/best_model.h5")
#print("\nProceso completado.")