import json
import os
import torch
import h5py
import numpy as np
import pandas as pd
from collections import defaultdict
from transformers import BertTokenizer, BertModel

# Configuración de BERT
model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained(model_name)
bert_model = BertModel.from_pretrained(model_name)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
bert_model.to(device)

# Nuevo máximo de tokens (cambiado de 512 a 72)
MAX_LENGTH = 72

# Contadores globales
stats = {
    'total_folders': 0,
    'processed': 0,
    'errors': 0,
    'reactions': defaultdict(int),
    'labels': defaultdict(int)
}

def safe_json_load(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading {filepath}: {str(e)}")
        return None

def convert_label(annotation, folder_path):
    if "non-rumours" in folder_path:
        return "non_rumour"
    
    if not isinstance(annotation, dict):
        return None
        
    misinfo = annotation.get('misinformation', 0)
    true = annotation.get('true', 0)
    
    try:
        misinfo = int(misinfo)
        true = int(true)
    except (ValueError, TypeError):
        return None
    
    if misinfo == 1 and true == 0:
        return "false"
    elif misinfo == 0 and true == 1:
        return "true"
    elif misinfo == 0 and true == 0:
        return "unverified"
    else:
        return None

def process_tweet_tree(tweet_dir):
    global stats
    
    # Cargar anotación
    annotation_path = os.path.join(tweet_dir, 'annotation.json')
    annotation = safe_json_load(annotation_path)
    if not annotation:
        stats['errors'] += 1
        return None
    
    # Obtener etiqueta
    label = convert_label(annotation, tweet_dir)
    if not label:
        stats['errors'] += 1
        return None
    
    # Cargar tweet fuente
    tweet_id = os.path.basename(tweet_dir)
    source_path = os.path.join(tweet_dir, 'source-tweets', f'{tweet_id}.json')
    source_data = safe_json_load(source_path)
    if not source_data or 'text' not in source_data:
        stats['errors'] += 1
        return None
    
    # Obtener reacciones
    reactions_dir = os.path.join(tweet_dir, 'reactions')
    reactions = []
    if os.path.exists(reactions_dir):
        for react_file in os.listdir(reactions_dir):
            if react_file.endswith('.json'):
                react_data = safe_json_load(os.path.join(reactions_dir, react_file))
                if react_data and 'text' in react_data:
                    reactions.append(react_data['text'])
    
    # Mostrar información detallada del árbol actual
    print(f"\n=== Procesando árbol {stats['processed'] + 1} ===")
    print(f"ID del tweet: {tweet_id}")
    print(f"Directorio: {tweet_dir}")
    print("\nContenido de annotation.json:")
    print(json.dumps(annotation, indent=2))
    print("\nTweet fuente:")
    print(source_data['text'])
    print(f"\nNúmero de reacciones: {len(reactions)}")
    if reactions:
        print("\nPrimeras 3 reacciones:")
        for i, react in enumerate(reactions[:3], 1):
            print(f"{i}. {react}")
    print(f"\nEtiqueta asignada: {label}")
    
    # Actualizar estadísticas
    stats['reactions'][len(reactions)] += 1
    stats['labels'][label] += 1
    stats['processed'] += 1
    
    return {
        'id': tweet_id,
        'text': source_data['text'],
        'reactions': reactions,
        'label': label
    }

def get_bert_embeddings(texts):
    print("\nGenerando embeddings para el texto combinado...")
    print(f"Texto de entrada (truncado a {MAX_LENGTH} tokens):")
    print(texts[0][:200] + "...")  # Mostrar solo el inicio para no saturar la salida
    
    inputs = tokenizer(texts, return_tensors='pt', padding='max_length', 
                      truncation=True, max_length=MAX_LENGTH).to(device)
    with torch.no_grad():
        outputs = bert_model(**inputs)
    
    embeddings = outputs.last_hidden_state.cpu().numpy()
    print(f"Dimensiones de los embeddings generados: {embeddings.shape}")
    return embeddings

def process_dataset(main_folder, output_file, batch_size=32):
    global stats
    
    # Inicializar archivo HDF5
    with h5py.File(output_file, 'w') as hf:
        embeddings_dset = None
        labels_dset = None
        
        # Procesar rumores y no rumores
        for rumor_type in ['rumours', 'non-rumours']:
            rumor_path = os.path.join(main_folder, rumor_type)
            if not os.path.exists(rumor_path):
                continue
                
            for tweet_id in os.listdir(rumor_path):
                tweet_dir = os.path.join(rumor_path, tweet_id)
                if not os.path.isdir(tweet_dir):
                    continue
                
                stats['total_folders'] += 1
                tweet_data = process_tweet_tree(tweet_dir)
                if not tweet_data:
                    continue
                
                # Procesar en lotes
                combined_text = tweet_data['text'] + " [SEP] " + " [SEP] ".join(tweet_data['reactions'])
                embedding = get_bert_embeddings([combined_text])[0]
                
                # Guardar en HDF5
                if embeddings_dset is None:
                    embeddings_dset = hf.create_dataset(
                        'embeddings', 
                        data=np.expand_dims(embedding, 0),
                        maxshape=(None, *embedding.shape),
                        chunks=True
                    )
                    labels_dset = hf.create_dataset(
                        'labels',
                        data=np.array([tweet_data['label']], dtype='S'),
                        maxshape=(None,),
                        chunks=True
                    )
                else:
                    embeddings_dset.resize(embeddings_dset.shape[0] + 1, axis=0)
                    embeddings_dset[-1:] = np.expand_dims(embedding, 0)
                    labels_dset.resize(labels_dset.shape[0] + 1, axis=0)
                    labels_dset[-1:] = np.array([tweet_data['label']], dtype='S')
                
                # Mostrar progreso cada 10 árboles
                if stats['processed'] % 10 == 0:
                    print(f"\n=== RESUMEN DE PROGRESO ===")
                    print(f"Total de árboles procesados: {stats['processed']}")
                    print(f"Último ID procesado: {tweet_id}")
                    print("Distribución actual de etiquetas:")
                    for label, count in stats['labels'].items():
                        print(f"- {label}: {count} ({count/stats['processed']:.1%})")

def print_stats():
    print("\n=== ESTADÍSTICAS FINALES ===")
    print(f"Total de carpetas encontradas: {stats['total_folders']}")
    print(f"Árboles procesados exitosamente: {stats['processed']}")
    print(f"Errores: {stats['errors']}")
    
    print("\nDistribución de etiquetas:")
    for label, count in stats['labels'].items():
        print(f"- {label}: {count} ({count/stats['processed']:.1%})")
    
    print("\nDistribución de reacciones por árbol:")
    for react_count, count in sorted(stats['reactions'].items()):
        print(f"- {react_count} reacciones: {count} árboles ({count/stats['processed']:.1%})")

# Configuración de rutas
base_path = os.path.dirname(os.getcwd())
main_folder = os.path.join(base_path, 'PreprocesamientoRD', 'Archivos preprocesados')
output_file = os.path.join(os.getcwd(), 'tree_embeddings.h5')  # Cambiado el nombre para reflejar el cambio

# Ejecución principal
if __name__ == "__main__":
    if not os.path.exists(main_folder):
        print(f"Error: No se encontró la carpeta {main_folder}")
    else:
        print(f"Iniciando procesamiento de todos los árboles con MAX_LENGTH={MAX_LENGTH}...")
        process_dataset(main_folder, output_file)
        print_stats()
        
        # Verificar resultados
        if os.path.exists(output_file):
            with h5py.File(output_file, 'r') as hf:
                print("\nResultados guardados:")
                print(f"Embeddings: {hf['embeddings'].shape}")  # Esperado: (N, 72, 768)
                print(f"Labels: {hf['labels'].shape}")
                print(f"Primeras etiquetas: {hf['labels'][:5]}")
        else:
            print("\nNo se creó el archivo de salida")