import os
import json
import re
import shutil
from collections import defaultdict

# Contadores iniciales
counters = {
    'total_files': 0,
    'processed_source_tweets': 0,
    'processed_reactions': 0,
    'copied_files': 0,
    'empty_files': 0,
    'invalid_files': 0,
    'urls_removed': 0,
    'mentions_removed': 0,
    'hashtags_removed': 0,
    'rumours': defaultdict(int),
    'non_rumours': defaultdict(int),
    'max_length': 0,
    'min_length': float('inf'),
    'total_length': 0,
    'text_count': 0
}

def clean_and_preprocess(text):
    if not isinstance(text, str):
        return "", 0
    
    original_text = text
    url_count = len(re.findall(r'http\S+|www\S+|https\S+', text, flags=re.MULTILINE))
    counters['urls_removed'] += url_count
    text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
    
    mention_count = len(re.findall(r'@\w+', text))
    counters['mentions_removed'] += mention_count
    text = re.sub(r'@\w+', '', text)
    
    hashtag_count = text.count('#')
    counters['hashtags_removed'] += hashtag_count
    text = re.sub(r'#', '', text)
    
    text = text.lower()
    text = re.sub(r'\s+', ' ', text).strip()
    
    length = len(text)
    return text, length

# Configuración de directorios
base_dir = os.getcwd()
print(f"\nDirectorio actual de trabajo: {base_dir}")

input_base_dir = os.path.join(base_dir, "Dataset original")
print(f"Directorio de entrada: {input_base_dir}")

output_dir = os.path.join(base_dir, "Archivos preprocesados")
print(f"Directorio de salida: {output_dir}")

# Verificación de directorios
if not os.path.exists(input_base_dir):
    print("\nERROR: No se encuentra el directorio 'Dataset original'")
    print(f"Ruta verificada: {input_base_dir}")
    print("\nContenido del directorio actual:")
    print(os.listdir(base_dir))
    exit()

os.makedirs(output_dir, exist_ok=True)

def read_json_file(file_path):
    if os.path.getsize(file_path) == 0:
        counters['empty_files'] += 1
        print(f"Archivo vacío: {file_path}")
        return None
    
    for encoding in ['utf-8', 'ISO-8859-1', 'latin1']:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                return json.load(f)
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            continue
    
    counters['invalid_files'] += 1
    print(f"No se pudo leer el archivo {file_path}")
    return None

# Procesar todas las carpetas en Dataset original
datasets = [d for d in os.listdir(input_base_dir) if os.path.isdir(os.path.join(input_base_dir, d))]

if not datasets:
    print("\nNo se encontraron carpetas dentro de 'Dataset original'")
    exit()

for dataset in datasets:
    input_dir = os.path.join(input_base_dir, dataset)
    print(f"\nProcesando dataset: {dataset}")
    print(f"Ruta completa: {input_dir}")
    
    print("Estructura encontrada:")
    for root, dirs, files in os.walk(input_dir):
        level = root.replace(input_dir, '').count(os.sep)
        indent = ' ' * 4 * (level)
        print(f"{indent}{os.path.basename(root)}/")
        subindent = ' ' * 4 * (level + 1)
        for f in files[:3]:
            print(f"{subindent}{f}")
        if len(files) > 3:
            print(f"{subindent}... y {len(files)-3} más")

    for root, dirs, files in os.walk(input_dir):
        for file in files:
            if not file.endswith('.json'):
                continue
                
            counters['total_files'] += 1
            file_path = os.path.join(root, file)
            
            is_rumour = 'rumours' in root.split(os.sep)
            category = 'rumours' if is_rumour else 'non_rumours'
            
            data = read_json_file(file_path)
            if not data:
                continue
                
            is_source_tweet = 'source-tweets' in root.split(os.sep)
            is_reaction = 'reactions' in root.split(os.sep)
            
            if isinstance(data, dict):
                if 'text' in data:
                    processed_text, text_length = clean_and_preprocess(data['text'])
                    data['text'] = processed_text
                    
                    if text_length > 0:
                        counters['max_length'] = max(counters['max_length'], text_length)
                        counters['min_length'] = min(counters['min_length'], text_length)
                        counters['total_length'] += text_length
                        counters['text_count'] += 1
                    
                    relative_path = os.path.relpath(root, input_dir)
                    output_subdir = os.path.join(output_dir, relative_path)
                    os.makedirs(output_subdir, exist_ok=True)
                    output_file_path = os.path.join(output_subdir, file)
                    
                    with open(output_file_path, 'w', encoding='utf-8') as out_f:
                        json.dump(data, out_f, ensure_ascii=False, indent=2)
                    
                    if is_source_tweet:
                        counters['processed_source_tweets'] += 1
                        counters[category]['source_tweets'] += 1
                    elif is_reaction:
                        counters['processed_reactions'] += 1
                        counters[category]['reactions'] += 1
                    else:
                        counters['copied_files'] += 1
                        counters[category]['other'] += 1
                else:
                    relative_path = os.path.relpath(root, input_dir)
                    output_subdir = os.path.join(output_dir, relative_path)
                    os.makedirs(output_subdir, exist_ok=True)
                    output_file_path = os.path.join(output_subdir, file)
                    shutil.copy(file_path, output_file_path)
                    counters['copied_files'] += 1
                    counters[category]['copied'] += 1

def print_statistics():
    print("\n=== Estadísticas de preprocesamiento ===")
    print(f"Total de archivos procesados: {counters['total_files']}")
    print(f"\nArchivos source-tweets procesados: {counters['processed_source_tweets']}")
    print(f"  - Rumours: {counters['rumours']['source_tweets']}")
    print(f"  - Non-rumours: {counters['non_rumours']['source_tweets']}")
    print(f"\nArchivos reactions procesados: {counters['processed_reactions']}")
    print(f"  - Rumours: {counters['rumours']['reactions']}")
    print(f"  - Non-rumours: {counters['non_rumours']['reactions']}")
    print(f"\nArchivos copiados sin procesar: {counters['copied_files']}")
    print(f"Archivos vacíos encontrados: {counters['empty_files']}")
    print(f"Archivos inválidos/no legibles: {counters['invalid_files']}")
    print("\n=== Elementos eliminados ===")
    print(f"URLs eliminadas: {counters['urls_removed']}")
    print(f"Menciones eliminadas: {counters['mentions_removed']}")
    print(f"Hashtags eliminados: {counters['hashtags_removed']}")
    
    if counters['text_count'] > 0:
        print("\n=== Estadísticas de longitud de texto ===")
        print(f"Longitud máxima: {counters['max_length']} caracteres")
        print(f"Longitud mínima: {counters['min_length']} caracteres")
        print(f"Longitud promedio: {counters['total_length'] / counters['text_count']:.2f} caracteres")
        print(f"Total de textos procesados: {counters['text_count']}")
    else:
        print("\nNo se encontraron textos para analizar la longitud")

print_statistics()
print("\nPreprocesamiento completado.")