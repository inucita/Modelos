import h5py
import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tensorflow.keras.utils import to_categorical, plot_model
from tensorflow.keras.layers import Input, LSTM, Dense, Dropout, Bidirectional, Concatenate
from tensorflow.keras.models import Model, save_model, load_model
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.optimizers import Adam
from tensorflow.keras import regularizers
from sklearn.model_selection import KFold
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score, confusion_matrix
import time
from openpyxl import load_workbook
import torch
from tensorflow.keras.layers import Input, Bidirectional, LSTM, Dropout, Dense, Concatenate, Lambda, Reshape

from tensorflow.keras import backend as K


# Configuración de directorios
MODELO_HS_DIR = os.path.join("/", "home", "lukas", "bredna", "modelos")
MODELO_RD_DIR = os.path.join("/", "home", "lukas", "bredna", "modelos", "ModeloRD")

def load_hate_speech_model():
    """Carga el modelo de hate speech pre-entrenado"""
    hs_model_path = os.path.join(MODELO_HS_DIR, "ModeloHS.h5")
    if not os.path.exists(hs_model_path):
        raise FileNotFoundError(f"No se encontró el modelo pre-entrenado en: {hs_model_path}")
    return load_model(hs_model_path)

def predict_hate_speech(embeddings, hs_model):
    """Predice hate speech para cada tweet y devuelve probabilidades"""
  

    

    if embeddings.shape[1] > 1:
        mean_embeddings = np.mean(embeddings, axis=1)
    else:
        mean_embeddings = np.squeeze(embeddings, axis=1)
    
    # Añadimos dimensión temporal para el modelo HS (n_samples, 1, embedding_dim)
    hs_input = np.expand_dims(mean_embeddings, axis=1)
    
    # Predecir
    hs_probs = hs_model.predict(hs_input, verbose=0)
    
  
    return hs_probs

def create_transfer_model_with_hs(input_shape, params, hs_model):
    """Crea un modelo de transfer learning con hate speech como feature adicional"""
    # Input para los embeddings de rumor detection
    rd_input = Input(shape=input_shape, name='rd_input')
    
    # Obtener predicciones de hate speech
    mean_embeddings = Lambda(lambda x: K.mean(x, axis=1))(rd_input) if input_shape[0] > 1 else rd_input
    hs_input = Reshape((1, input_shape[-1]))(mean_embeddings)
    hs_probs = hs_model(hs_input)
    
    # Procesar embeddings de rumor detection
    x = Bidirectional(LSTM(params['units'], return_sequences=True))(rd_input)
    x = Dropout(params['dropout'])(x)
    x = Bidirectional(LSTM(params['units'] // 2))(x)
    x = Dropout(params['dropout'])(x)
    
    # Concatenar con predicciones de hate speech
    x = Concatenate()([x, hs_probs])
    
    # Capas adicionales
    x = Dense(64, activation='relu', 
              kernel_regularizer=regularizers.l1_l2(l1=0.0001, l2=0.0001))(x)
    x = Dropout(params['dropout'])(x)
    output_layer = Dense(3, activation='softmax')(x)
    
    # Crear modelo final
    model = Model(inputs=rd_input, outputs=output_layer)
    
    return model

def load_data_with_structure_and_embeddings(structure_dir, embeddings_h5_path):
    """Cargar datos directamente desde el archivo de embeddings HDF5."""
    print("\n" + "="*50)
    print("INICIANDO CARGA DE DATOS DESDE ARCHIVO DE EMBEDDINGS")
    print("="*50)

    if not os.path.exists(embeddings_h5_path):
        print(f"¡Error! Archivo no encontrado: {embeddings_h5_path}")
        return None, None

    try:
        with h5py.File(embeddings_h5_path, 'r') as f:
            if 'embeddings' not in f or 'labels' not in f:
                print("¡Error! El archivo no contiene los datasets 'embeddings' o 'labels'.")
                return None, None

            X = f['embeddings'][:]
            labels_bytes = f['labels'][:]
            y_raw = [label.decode('utf-8') for label in labels_bytes]

            label_mapping = {'non_r': 0, 'true': 1, 'false': 0, 'unver': 2}
            y = np.array([label_mapping.get(label, 2) for label in y_raw])

            print(f"Embeddings cargados correctamente. Shape de X: {X.shape}")
            print(f"Etiquetas cargadas correctamente. Shape de y: {y.shape}")

            return X, y

    except Exception as e:
        print(f"Error al cargar datos desde HDF5: {e}")
        return None, None

def save_results_to_excel(results_df, results_path):
    """Guarda los resultados en un archivo Excel"""
    try:
        if os.path.exists(results_path):
            backup_path = results_path.replace('.xlsx', '_backup.xlsx')
            os.replace(results_path, backup_path)
            
            with pd.ExcelWriter(results_path, engine='openpyxl') as writer:
                results_df.to_excel(writer, sheet_name='Resultados', index=False)
            
            print(f"\nResultados guardados en: {results_path} (backup creado)")
        else:
            with pd.ExcelWriter(results_path, engine='openpyxl') as writer:
                results_df.to_excel(writer, sheet_name='Resultados', index=False)
            print(f"\nResultados guardados en: {results_path}")
            
    except Exception as e:
        print(f"\n¡Error al guardar resultados! {str(e)}")
        new_path = results_path.replace('.xlsx', '_nuevo.xlsx')
        with pd.ExcelWriter(new_path, engine='openpyxl') as writer:
            results_df.to_excel(writer, sheet_name='Resultados', index=False)
        print(f"Resultados guardados en: {new_path}")

def calculate_metrics(y_true, y_pred):
    """Calcula todas las métricas requeridas"""
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'precision_0': precision_score(y_true, y_pred, average=None, zero_division=0)[0],
        'precision_1': precision_score(y_true, y_pred, average=None, zero_division=0)[1],
        'precision_2': precision_score(y_true, y_pred, average=None, zero_division=0)[2],
        'precision_macro': precision_score(y_true, y_pred, average='macro', zero_division=0),
        'recall_0': recall_score(y_true, y_pred, average=None, zero_division=0)[0],
        'recall_1': recall_score(y_true, y_pred, average=None, zero_division=0)[1],
        'recall_2': recall_score(y_true, y_pred, average=None, zero_division=0)[2],
        'recall_macro': recall_score(y_true, y_pred, average='macro', zero_division=0),
        'f1_0': f1_score(y_true, y_pred, average=None, zero_division=0)[0],
        'f1_1': f1_score(y_true, y_pred, average=None, zero_division=0)[1],
        'f1_2': f1_score(y_true, y_pred, average=None, zero_division=0)[2],
        'f1_macro': f1_score(y_true, y_pred, average='macro', zero_division=0),
        'confusion_matrix': confusion_matrix(y_true, y_pred)
    }
    return metrics

def save_model_plot(model, exp_num, results_dir):
    """Guarda el diagrama del modelo"""
    try:
        model_plots_dir = os.path.join(results_dir, "model_plots")
        os.makedirs(model_plots_dir, exist_ok=True)
        
        plot_path = os.path.join(model_plots_dir, f"model_architecture_exp_{exp_num}.png")
        plot_model(model, to_file=plot_path, show_shapes=True, show_layer_names=True)
        print(f"\nDiagrama del modelo guardado en: {plot_path}")
    except Exception as e:
        print(f"\nNo se pudo generar el diagrama del modelo: {str(e)}")

def save_model_h5(model, exp_num, results_dir):
    """Guarda el modelo en formato h5"""
    try:
        models_dir = os.path.join(results_dir, "saved_models")
        os.makedirs(models_dir, exist_ok=True)
        
        model_path = os.path.join(models_dir, f"model_exp_{exp_num}.h5")
        save_model(model, model_path)
        print(f"\nModelo guardado en: {model_path}")
    except Exception as e:
        print(f"\nNo se pudo guardar el modelo: {str(e)}")

def create_plots(history, exp_num, fold_num, results_dir):
    """Crea y guarda los gráficos de entrenamiento"""
    try:
        plots_dir = os.path.join(results_dir, "training_plots")
        os.makedirs(plots_dir, exist_ok=True)
        
        train_acc = history.history['accuracy']
        val_acc = history.history.get('val_accuracy', [])
        train_loss = history.history['loss']
        val_loss = history.history.get('val_loss', [])
        epochs = range(1, len(train_acc) + 1)
        
        # Gráfico combinado
        plt.figure(figsize=(12, 6))
        plt.plot(epochs, train_acc, 'b-', label='Entrenamiento Accuracy')
        if val_acc:
            plt.plot(epochs, val_acc, 'r-', label='Validación Accuracy')
        plt.plot(epochs, train_loss, 'b--', label='Entrenamiento Loss')
        if val_loss:
            plt.plot(epochs, val_loss, 'r--', label='Validación Loss')
        plt.title(f'Exp {exp_num} Fold {fold_num} - Accuracy y Loss')
        plt.xlabel('Épocas')
        plt.ylabel('Métrica')
        plt.legend()
        plt.grid(True)
        
        combined_path = os.path.join(plots_dir, f"GraficoExp{exp_num}fold{fold_num}RD_VALTRAIN.png")
        plt.savefig(combined_path)
        plt.close()
        
        print(f"Gráficos guardados en: {plots_dir}")
        
    except Exception as e:
        print(f"Error al crear gráficos: {str(e)}")

def run_experiments(X, y, results_dir, hs_model):
    """Ejecuta experimentos con Transfer Learning y Hate Speech como feature adicional"""
    print("\n" + "="*50)
    print("INICIANDO EXPERIMENTOS CON TRANSFER LEARNING + HATE SPEECH FEATURE")
    print("="*50)
    
    experiments = [
        {'lr': 0.0005, 'dropout': 0.3, 'reg': 'l1', 'es': False, 'units': 128},
        {'lr': 0.0005, 'dropout': 0.3, 'reg': 'l2', 'es': False, 'units': 64},
        {'lr': 0.0005, 'dropout': 0.3, 'reg': 'l2', 'es': False, 'units': 128},
        {'lr': 0.001, 'dropout': 0.3, 'reg': 'l1', 'es': False, 'units': 64},
        {'lr': 0.001, 'dropout': 0.3, 'reg': 'l1', 'es': False, 'units': 128},
        {'lr': 0.001, 'dropout': 0.3, 'reg': 'l2', 'es': False, 'units': 64},
        {'lr': 0.001, 'dropout': 0.3, 'reg': 'l2', 'es': False, 'units': 128},
    ]
    
    results_path = os.path.join(results_dir, "resultados_experimentos.xlsx")
    
    columns = [
        'Experiment', 'Learning Rate', 'Dropout Rate', 'Regularization', 
        'Early Stopping', 'Units', 'Fold', 
        'Accuracy', 'Loss', 'Training Time', 
        'Epochs Completed', 'Best Epoch',
        'Precision_0', 'Precision_1', 'Precision_2', 'Precision_Macro',
        'Recall_0', 'Recall_1', 'Recall_2', 'Recall_Macro',
        'F1_0', 'F1_1', 'F1_2', 'F1_Macro',
        'Val Accuracy History', 'Val Loss History',
        'Train Accuracy History', 'Train Loss History',
        'Confusion Matrix', 'Model Type'
    ]
    
    results_df = pd.DataFrame(columns=columns)
    
    print(f"\nForma de los datos de entrada: {X.shape}")
    print(f"Forma de las etiquetas: {y.shape}")
    
    for exp_num, exp_config in enumerate(experiments, 1):
        lr = exp_config['lr']
        dropout = exp_config['dropout']
        reg = exp_config['reg']
        es = exp_config['es']
        units = exp_config['units']
        
        print(f"\n{'='*30}")
        print(f"EXPERIMENTO {exp_num} (TRANSFER LEARNING + HS FEATURE)")
        print(f"LR={lr}, Dropout={dropout}, Reg={reg}, ES={'Sí' if es else 'No'}, Units={units}")
        print(f"{'='*30}")
        
        kf = KFold(n_splits=5, shuffle=True, random_state=42)
        
        for fold_num, (train_index, val_index) in enumerate(kf.split(X), 1):
            X_train, X_val = X[train_index], X[val_index]
            y_train, y_val = y[train_index], y[val_index]

            print(f"\nFold {fold_num}/5 - Preparando modelo...")

            try:
                start_time = time.time()

                # Crear modelo con hate speech como feature adicional
                model = create_transfer_model_with_hs(
                    input_shape=X_train.shape[1:],
                    params={
                        'dropout': dropout,
                        'units': units
                    },
                    hs_model=hs_model
                )
                
                model.compile(
                    optimizer=Adam(learning_rate=lr),
                    loss='categorical_crossentropy',
                    metrics=['accuracy']
                )
                
                if fold_num == 1:
                    save_model_plot(model, exp_num, results_dir)
                
                callbacks = []
                if es:
                    early_stopping = EarlyStopping(
                        monitor='val_loss',
                        patience=3,
                        restore_best_weights=True,
                        verbose=1
                    )
                    callbacks.append(early_stopping)

                history = model.fit(
                    X_train, y_train,
                    validation_data=(X_val, y_val),
                    epochs=400,
                    batch_size=32,
                    callbacks=callbacks,
                    verbose=1
                )

                val_loss, val_acc = model.evaluate(X_val, y_val, verbose=0)
                y_pred = model.predict(X_val, verbose=0)
                y_pred_classes = np.argmax(y_pred, axis=1)
                y_true_classes = np.argmax(y_val, axis=1)

                metrics = calculate_metrics(y_true_classes, y_pred_classes)

                training_time = time.time() - start_time
                epochs_completed = len(history.history['loss'])
                best_epoch = np.argmin(history.history['val_loss']) + 1 if es else epochs_completed

                train_acc_history = history.history['accuracy']
                val_acc_history = history.history.get('val_accuracy', [])
                train_loss_history = history.history['loss']
                val_loss_history = history.history.get('val_loss', [])

                create_plots(history, exp_num, fold_num, results_dir)

                if fold_num == 1:
                    save_model_h5(model, exp_num, results_dir)

                new_row = {
                    'Experiment': exp_num,
                    'Learning Rate': lr,
                    'Dropout Rate': dropout,
                    'Regularization': reg,
                    'Early Stopping': 'Yes' if es else 'No',
                    'Units': units,
                    'Fold': fold_num,
                    'Accuracy': val_acc,
                    'Loss': val_loss,
                    'Training Time': training_time,
                    'Epochs Completed': epochs_completed,
                    'Best Epoch': best_epoch,
                    'Precision_0': metrics['precision_0'],
                    'Precision_1': metrics['precision_1'],
                    'Precision_2': metrics['precision_2'],
                    'Precision_Macro': metrics['precision_macro'],
                    'Recall_0': metrics['recall_0'],
                    'Recall_1': metrics['recall_1'],
                    'Recall_2': metrics['recall_2'],
                    'Recall_Macro': metrics['recall_macro'],
                    'F1_0': metrics['f1_0'],
                    'F1_1': metrics['f1_1'],
                    'F1_2': metrics['f1_2'],
                    'F1_Macro': metrics['f1_macro'],
                    'Val Accuracy History': str(val_acc_history),
                    'Val Loss History': str(val_loss_history),
                    'Train Accuracy History': str(train_acc_history),
                    'Train Loss History': str(train_loss_history),
                    'Confusion Matrix': str(metrics['confusion_matrix']),
                    'Model Type': 'Transfer Learning + HS Feature'
                }

                results_df = pd.concat([results_df, pd.DataFrame([new_row])], ignore_index=True)
                save_results_to_excel(results_df, results_path)

                print(f"\nFold {fold_num}/5 completado")
                print(f"Accuracy: {val_acc:.4f} | F1 Macro: {metrics['f1_macro']:.4f}")

            except Exception as e:
                print(f"\n¡Error en Fold {fold_num}!: {str(e)}")
                continue
    
    return results_df

def main():
    """Función principal para Transfer Learning con Hate Speech como feature adicional"""
    print("INICIANDO PROGRAMA PRINCIPAL (TRANSFER LEARNING + HS FEATURE)")
    
    # Configuración de rutas
    base_path = os.path.join("/", "home", "lukas", "bredna", "modelos")
    modelo_rd_path = os.path.join(base_path, "ModeloRD")
    results_dir = os.path.join(modelo_rd_path, "resultados")
    os.makedirs(results_dir, exist_ok=True)
    
    # Cargar modelo de hate speech
    hs_model = load_hate_speech_model()
    
    # Cargar datos de rumor detection
    structure_dir = os.path.join(modelo_rd_path, "PreprocesamientoRD", "Archivos preprocesados")
    embeddings_h5_path = os.path.join(modelo_rd_path, "EmbeddingsRD", "tree_embeddings.h5")
    
    X, y = load_data_with_structure_and_embeddings(structure_dir, embeddings_h5_path)
    if X is None or y is None:
        return
    
    # Preprocesamiento
    y = to_categorical(y, num_classes=3)
    if len(X.shape) == 2:
        X = np.expand_dims(X, axis=1)
    
    # Ejecutar experimentos con transfer learning + hate speech feature
    results_df = run_experiments(X, y, results_dir, hs_model)
    
    # Guardar resultados finales
    final_path = os.path.join(results_dir, "resultados_finales.xlsx")
    save_results_to_excel(results_df, final_path)
    
    # Análisis final
    if not results_df.empty:
        best_exp = results_df.loc[results_df['F1_Macro'].idxmax()]
        print("\n" + "="*50)
        print(f"MEJOR EXPERIMENTO (TRANSFER LEARNING + HS FEATURE): #{best_exp['Experiment']}")
        print(f"F1 Macro: {best_exp['F1_Macro']:.4f}")
        print("Matriz de confusión:")
        print(best_exp['Confusion Matrix'])
        print("="*50)

if __name__ == "__main__":
    main()